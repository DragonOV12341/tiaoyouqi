export APP_SOURCE_PATH=/pyf/test/conv_exsample
export DDK_PATH=/usr/local/Ascend//ascend-toolkit/latest
export NPU_HOST_LIB=/usr/local/Ascend//ascend-toolkit/latest/x86_64-linux/devlib