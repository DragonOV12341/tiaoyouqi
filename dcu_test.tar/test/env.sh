export DTK_HOME="/opt/dtk-24.04.1"
export PATH="${NEUWARE_HOME}/bin:${PATH}"
export LD_LIBRARY_PATH="${NEUWARE_HOME}/lib:${LD_LIBRARY_PATH}"
export LIBRARY_PATH="${NEUWARE_HOME}/lib:${LIBRARY_PATH}"

# MIOpen rocblas